package components;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;

public class SimonFrame extends JFrame{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static ColorPanel redPanel= new ColorPanel(Color.RED);
	public static ColorPanel yellowPanel= new ColorPanel(Color.YELLOW);
	public static ColorPanel bluePanel= new ColorPanel(Color.BLUE);
	public static ColorPanel greenPanel= new ColorPanel(Color.GREEN);
	public static JButton newGame = new JButton("New Game");
	public static JLabel scoreArea = new JLabel();
	public static JLabel highscoreArea = new JLabel("2");
	
	/**
	 * creates new game frame object
	 */
	public SimonFrame(){
		Container pane = this.getContentPane();
		Container scoreAreaContainer = new Container();
		Container panelAreaContainer = new Container();
		scoreAreaContainer.setLayout(new GridLayout(1,3));
		scoreAreaContainer.add(scoreArea);
		scoreAreaContainer.add(newGame);
		scoreAreaContainer.add(highscoreArea);
		panelAreaContainer.setLayout(new GridLayout(2,2));
		panelAreaContainer.add(redPanel);
		panelAreaContainer.add(bluePanel);
		panelAreaContainer.add(greenPanel);
		panelAreaContainer.add(yellowPanel);
		
		pane.setLayout(new BorderLayout());
		pane.add(scoreAreaContainer,BorderLayout.NORTH);
		pane.add(panelAreaContainer,BorderLayout.CENTER);
		this.pack();
		this.setSize(400, 400);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		
		
		
		
	}
	
	
}
