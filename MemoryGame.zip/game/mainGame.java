/**
 * 
 */
package game;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Random;
import java.util.Vector;

import components.ColorPanel;
import components.HighScoreWindow;
import components.SimonFrame;
import components.GetInputWindow;
import components.HighScoreSet;

/**
 * @author Ben_2
 *
 */
public class mainGame {

	private static MouseListener listener = new MouseListener(){

		@Override
		public void mouseClicked(MouseEvent e) {
			// TODO Auto-generated method stub
			if ( e.getSource()==inputWindow.done){
				playerName = inputWindow.inputValue;
				//makeHighScoreWindow();
				
			}
			if ( e.getSource()==SimonFrame.newGame){
				newGame();
			}
			if ( turn == "human"){
			if (e.getSource() == SimonFrame.redPanel){
				humanMove("red");
			}
			if (e.getSource() == SimonFrame.bluePanel){
				humanMove("blue");
			}
			if (e.getSource() == SimonFrame.yellowPanel){
				humanMove("yellow");
			}
			if (e.getSource() == SimonFrame.greenPanel){
				humanMove("green");
			}
			}
		}


		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mousePressed(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
		
	};
	private static String playerName;
	private static Vector<String> sequence = new Vector<String>() ;
	private static Integer score = 0;
	private static int iterater = 0;
	private static String turn = "computer";
	static SimonFrame frame = new SimonFrame();
	private static HighScoreSet highScoreSet = new HighScoreSet();
	static GetInputWindow inputWindow = new GetInputWindow();
	private static Integer highscore = 2;
	

	/**
	 * @param args
	 */
	static void addListeners(SimonFrame frame){
		SimonFrame.redPanel.addMouseListener(listener);
		SimonFrame.yellowPanel.addMouseListener(listener);
		SimonFrame.bluePanel.addMouseListener(listener);
		SimonFrame.greenPanel.addMouseListener(listener);
		SimonFrame.newGame.addMouseListener(listener);
		inputWindow.done.addMouseListener(listener);
	}

	
	/**
	 * makes new game
	 */
	static void newGame(){
		
		score = 0;
		iterater = 0;
		sequence = new Vector<String>();
		
		computerTurn();
	}
	
	/**
	 * plays computer turn
	 */
	private static void computerTurn() {
		turn  = "computer";
		String newColor = getRandColor();
		sequence.addElement(newColor);
		for(String c:sequence){
			flash(c);
		}
		turn = "human";
		
	}
	
	/**
	 * makes human move
	 * @param c is color that human clicked
	 */
	private static void humanMove(String c){
		flash(c);
		if ( sequence.elementAt(iterater) == c){
			iterater++;
		}
		else {
			endGame();
		}
		if (iterater == sequence.size() ){
			humanWinRound();
		}
	}
	
	/**
	 * increases score after ending a round
	 */
private static void incrementScore(){
	score++;
	SimonFrame.scoreArea.setText("Score: "+score.toString());
	SimonFrame.scoreArea.update(SimonFrame.scoreArea.getGraphics());
}

/**
 * when human finishes round
 */
private static void humanWinRound() {
	incrementScore();
	iterater = 0;
	frame.update(frame.getGraphics());
	computerTurn();
	}

/**
 * 
 * @return 
 * @return string of player's name
 */
private static  void getNameWindow() {
	
	inputWindow.done.addMouseListener(listener);
	inputWindow.setVisible(true);
	
}


private static void makeHighScoreWindow() {
	HighScore newScore = new HighScore(playerName, score);
	highScoreSet.addScore(newScore);
	HighScoreWindow highScoreWindow = new HighScoreWindow(highScoreSet);
	
}

/**
 * ends game
 */
private static void endGame() {
	inputWindow.setVisible(true);
	if (score >= highscore){
		highscore = score;
		SimonFrame.highscoreArea.setText("HighScore: "+highscore.toString());
		SimonFrame.highscoreArea.update(SimonFrame.highscoreArea.getGraphics());
	}
	}



/**
 * flashes the color for .5 second
 * @param cPanel
 */
static void flashHelper(ColorPanel cPanel){
	
	cPanel.brighten();

	try {
	    Thread.sleep(500);                 //1000 milliseconds is one second.
	} catch(InterruptedException ex) {
	    Thread.currentThread().interrupt();
	}
	cPanel.darken();
}
/**
 * flashes the appropriate color
 * @param c
 */
	private static void flash(String c) {
		switch (c){
		case "red":
			flashHelper(SimonFrame.redPanel);
			break;
		case "green":
			flashHelper(SimonFrame.greenPanel);
			break;
		case "yellow":
			flashHelper(SimonFrame.yellowPanel);
			break;
		case "blue":
			flashHelper(SimonFrame.bluePanel);
			break;
		}
	}


/**
 * 
 * @return string representing 1 f 4 color panels
 */
	private static String getRandColor() {
	
		Random rand=new Random() ;
		int ColorInt = rand.nextInt(4);
		
		switch (ColorInt){
		case 0:
			return "red";
		case 1:
			return "blue";
		case 2: 
			return "yellow";
		case 3:
			return "green";
		}
		return null;
	}
 
	/**
	 * sets the score initially
	 */
	private static void setupframe() {
		SimonFrame.scoreArea.setText(score.toString());
		
	}

/**
 * begins game
 * @param args does nothing
 */
	public static void main(String[] args) {
		
		addListeners(frame);
		setupframe();
		
		
	}








}
