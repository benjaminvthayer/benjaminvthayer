package game;

/**
 * stores a name and a score in  a highscore
 * @author Ben_2
 *
 */
public class HighScore {

public String name;
public Integer score;

/**
 * constructs highscore
 * @param n name
 * @param sc  score
 */
public HighScore(String n, Integer sc){
	score = sc;
	name = n;
}

/**
 * makes highscore into printable string
 */
public String toString(){
	return name+" "+score;
}
}

