package components;

import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JRadioButton;

/*
public class SpeedWindow extends JFrame{
	Container pane = this.getContentPane();
	JRadioButton slowButton = new JRadioButton("Slow");
	JRadioButton mediumButton = new JRadioButton("Medium");
	JRadioButton fastButton = new JRadioButton("Fast");
	ButtonGroup buttonGroup = new ButtonGroup();
	JButton   doneButton = new JButton("Select");
	
	SpeedWindow(){

		buttonGroup.add(fastButton);
		buttonGroup.add(slowButton);
		buttonGroup.add(mediumButton);
		
		this.setTitle("Set Speed");
		pane.setBackground(Color.WHITE);
		pane.setLayout(new GridLayout(4,1));
		pane.add(slowButton);
		pane.add(mediumButton);
		pane.add(fastButton);
		pane.add(doneButton);
		this.pack();
		this.setSize(300,150);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}
}


*/