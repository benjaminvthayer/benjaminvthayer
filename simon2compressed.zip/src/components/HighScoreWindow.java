/**
 * 
 */
package components;

import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;

import game.HighScore;

/**
 * @author Ben_2
 *
 */
@SuppressWarnings("serial")
public class HighScoreWindow extends JFrame {
	Container pane = this.getContentPane();
	static JLabel scoresArea1 = new JLabel();
	static JLabel scoresArea2 = new JLabel();
	static JLabel scoresArea3= new JLabel();

	
	/**
	 * creates high score window
	 * @param highScores vector generated in mainGame
	 */
	public HighScoreWindow( HighScoreSet scoreSet){
		Integer rank = 1;
		this.setTitle("HighScores");
		pane.setBackground(Color.WHITE);
		pane.setLayout(new GridLayout(3,1));
		
		pane.add(scoresArea1);
		pane.add(scoresArea2);
		pane.add(scoresArea3);
		scoresArea1.setText( scoreSet.getScore(1));
		scoresArea1.setText( scoreSet.getScore(2));
		scoresArea1.setText( scoreSet.getScore(3));
	
		this.pack();
		this.setSize(400,200);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		
	}
	
	
}
