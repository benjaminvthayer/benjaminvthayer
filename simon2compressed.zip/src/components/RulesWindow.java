package components;


import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;

/**
 * @author Ben_2
 *
 */
@SuppressWarnings("serial")
public class RulesWindow extends JFrame {
	Container pane = this.getContentPane();
	static JTextArea scoresArea1 = new JTextArea();


	
	/**
	 * creates high score window
	 * @param highScores vector generated in mainGame
	 */
	public RulesWindow(){
	
		this.setTitle("About Game");
		pane.setBackground(Color.WHITE);
		
		scoresArea1.setText("Correctly match the sequence flashed by the \ncomputer. If you mess up, you lose\n and start over.\nTo win, continue until the \nsequence length is infinity.");                                                                                                                                 
		pane.add(scoresArea1);
	
	
		this.pack();
		this.setSize(300,150);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		
	}
	
	
}