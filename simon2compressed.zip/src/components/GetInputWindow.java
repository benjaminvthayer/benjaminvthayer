package components;


import java.awt.Container;
import java.awt.GridLayout;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class GetInputWindow extends JFrame{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Container pane = this.getContentPane();
	private MouseListener listener = new MouseListener(){

		@Override
		public void mouseClicked(MouseEvent e) {
			if (e.getSource()==done){
				closeWindow();
			}
			
		}

		@Override
		public void mouseEntered(MouseEvent arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseExited(MouseEvent arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mousePressed(MouseEvent arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseReleased(MouseEvent arg0) {
			// TODO Auto-generated method stub
			
		}
		
	};
	public String inputValue = "";
	
	static JLabel prompt = new JLabel("Enter Your Name Here:");
	public static JTextField input = new JTextField();
	public static JButton done = new JButton("Ok");
	
	/**
	 * creates high score window
	 * @param highScores vector generated in mainGame
	 */
	public GetInputWindow( ){
		pane.setLayout(new GridLayout(3,1));
		pane.add(prompt);
		pane.add(input);
		pane.add(done);
		done.addMouseListener(listener );
		this.pack();
		this.setSize(200,200);
		this.setLocationRelativeTo(null);
		
		
	}
	void closeWindow(){
		this.setVisible(false);
		this.dispose();
	}
}
