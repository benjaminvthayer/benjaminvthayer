/**
 * 
 */
package components;



import java.awt.Color;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * @author Ben_2
 *
 */
public class ColorPanel extends JPanel{
	/**
	 * to make the IDE happy
	 */
	private static final long serialVersionUID = 1L;
	
	ImageIcon pic = new ImageIcon("penguin.jpg");
	
	public Color color;
	
	/**
	 * creates panel based on
	 * @param c a color 
	 */
	ColorPanel(Color c){
		color = c;
		this.setBackground(color.darker().darker());
		this.add(new JLabel(pic));
		this.update(this.getGraphics());
	
	}
	/**
	 * darkens the panel to normal state
	 */
	public void darken(){
		this.setBackground(color.darker().darker());
		this.update(this.getGraphics());
	}
	
	/**
	 * brightens the panel when clicked
	 */
	public void brighten(){
		this.setBackground(color.brighter());
		this.update(this.getGraphics());
	}
	
}
