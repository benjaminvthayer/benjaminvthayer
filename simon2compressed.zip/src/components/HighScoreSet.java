package components;

import java.util.Vector;

import game.HighScore;

public class HighScoreSet {
Vector<HighScore> highscores = new Vector<HighScore>();
private int newScorePosition = -1;
private int I;
	public HighScoreSet(){
		HighScore score1= new HighScore("Joe", 2);
		HighScore score2= new HighScore("Joseph Stalin", 1);
		HighScore score3= new HighScore("Cratin", 0);
		highscores.addElement(score1);
		highscores.addElement(score2);
		highscores.addElement(score3);
	}
	
	
	public void addScore(HighScore newScore) {
		
		
		for( int i = highscores.size()-1; i>=0;i--){
			if ( highscores.elementAt(i).score <newScore.score){
				newScorePosition  = i;
			}
			I = i;
		}
		if (newScorePosition != -1){
			highscores.add(I,newScore);
		}
	}

	

	public String getScore(Integer i) {
		HighScore curScore = highscores.elementAt(i-1);
		return  i.toString() + ": "+curScore.name +" "+ curScore.score.toString() ;
	}

}
