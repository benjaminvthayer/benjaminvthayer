package components;


import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;

/**
 * @author Ben_2
 *
 */
@SuppressWarnings("serial")
public class AboutWindow extends JFrame {
	Container pane = this.getContentPane();
	static JTextArea scoresArea1 = new JTextArea();


	
	/**
	 * creates high score window
	 * @param highScores vector generated in mainGame
	 */
	public AboutWindow(){
	
		this.setTitle("About Game");
		pane.setBackground(Color.WHITE);
		
		scoresArea1.setText("Simonish game. \n Click new game. \n Computer will flash a \nsequence of initialy one color. \n Remember the colors, and \nclick on them in the\n correct order.  The computer will then add \nanother color to the sequence.");                                                                            
		pane.add(scoresArea1);
	
	
		this.pack();
		this.setSize(375,225);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		
	}
	
	
}
