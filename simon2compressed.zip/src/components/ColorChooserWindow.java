package components;


import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;

import javax.swing.JColorChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;

/**
 * @author Ben_2
 *
 *//*
@SuppressWarnings("serial")
public class ColorChooserWindow extends JFrame {
	
	JColorChooser colorChooser = new JColorChooser();
	
	
	
	
	/**
	 * creates high score window
	 * @param highScores vector generated in mainGame
	 *//*
	public ColorChooserWindow(){
	
		
		this.setContentPane(colorChooser);
		
		
		this.pack();
		this.setSize(400,250);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		
	}
	
	
}



*/