package components;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JTextArea;

public class SimonFrame extends JFrame{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static ColorPanel redPanel= new ColorPanel(Color.RED);
	public static ColorPanel yellowPanel= new ColorPanel(Color.YELLOW);
	public static ColorPanel bluePanel= new ColorPanel(Color.BLUE);
	public static ColorPanel greenPanel= new ColorPanel(Color.GREEN);
	
	
	public static JButton newGame = new JButton("New Game");
	public static JLabel scoreArea = new JLabel();
	public static JLabel highscoreArea = new JLabel("2");
	public static JMenuBar menu = new JMenuBar();
	public static JMenu settings = new JMenu("Settings");
	public static JMenu stats = new JMenu("Stats");
	public static JMenu help = new JMenu("Help");
	public static JMenuItem settingsChooseColor = new JMenuItem("Choose Color");
	public static JMenuItem settingsChooseMode = new JMenuItem("Choose Mode");
	public static JMenuItem statsHighScores = new JMenuItem("High Scores");
	public static JMenuItem statsHistory = new JMenuItem("History");
	public static JMenuItem helpAbout = new JMenuItem("About");
	public static JMenuItem helpRules = new JMenuItem("Rules");
	
	static void setUpMenu(){
		settings.add(settingsChooseColor);
		settings.add(settingsChooseMode);
		stats.add(statsHighScores);
		stats.add(statsHistory);
		help.add(helpAbout);
		help.add(helpRules);
		menu.add(settings);
		menu.add(stats);
		menu.add(help);
	}
	
	/**
	 * creates new game frame object
	 */
	public SimonFrame(){
		Container pane = this.getContentPane();
		Container northContainer = new Container();
		Container scoreAreaContainer = new Container();
		Container panelAreaContainer = new Container();
		scoreAreaContainer.setLayout(new GridLayout(1,3));
		scoreAreaContainer.add(scoreArea);
		scoreAreaContainer.add(newGame);
		scoreAreaContainer.add(highscoreArea);
		
		
		
		northContainer.setLayout(new GridLayout(2,1));
		setUpMenu();
		northContainer.add(menu);
		northContainer.add(scoreAreaContainer);
		panelAreaContainer.setLayout(new GridLayout(2,2));
		panelAreaContainer.add(redPanel);
		panelAreaContainer.add(bluePanel);
		panelAreaContainer.add(greenPanel);
		panelAreaContainer.add(yellowPanel);
		pane.setLayout(new BorderLayout());
		pane.add(northContainer,BorderLayout.NORTH);
		pane.add(panelAreaContainer,BorderLayout.CENTER);
		this.pack();
		this.setSize(400, 400);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		
		
		
		
	}
	
	
}
